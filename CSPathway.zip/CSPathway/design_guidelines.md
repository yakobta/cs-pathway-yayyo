# CS Learning Platform - Design Guidelines

## Design Approach
**Hybrid System-Based Design** inspired by Linear's clean developer-focused UI, Notion's content organization, and VS Code's editor aesthetics. This creates a professional, efficient learning environment optimized for long study sessions and complex information consumption.

---

## Core Design Principles
1. **Information Clarity** - Content hierarchy that supports learning flow
2. **Developer Aesthetics** - Clean, technical design that resonates with CS students
3. **Progress Visibility** - Always show where users are in their learning journey
4. **Distraction-Free** - Minimal animations, focus on content consumption

---

## Color Palette

### Dark Mode (Primary)
- **Background:** 220 15% 8% (Deep navy-charcoal)
- **Surface:** 220 13% 12% (Elevated panels)
- **Surface Elevated:** 220 13% 16% (Cards, modals)
- **Border:** 220 13% 22% (Subtle divisions)

### Semantic Colors
- **Primary (Learning):** 217 91% 60% (Vibrant blue - represents knowledge)
- **Success (Completed):** 142 71% 45% (Green - chapter completion)
- **Warning (In Progress):** 38 92% 50% (Orange - active learning)
- **Accent (Interactive):** 262 83% 58% (Purple - code execution, highlights)

### Text Colors
- **Primary Text:** 220 13% 95%
- **Secondary Text:** 220 9% 70%
- **Muted Text:** 220 9% 50%
- **Code Syntax:** Inherit from Monaco Editor's VS Dark theme for consistency

---

## Typography

### Font Families
- **Display/Headers:** Inter (700-800 weight) - Clean, technical feel
- **Body Content:** Inter (400-500 weight) - Excellent readability
- **Code/Monospace:** Fira Code or JetBrains Mono - Ligatures enabled for code blocks

### Type Scale
- **Hero/Page Title:** text-4xl md:text-5xl font-bold (48-60px)
- **Section Headers:** text-2xl md:text-3xl font-semibold (30-36px)
- **Chapter Titles:** text-xl font-semibold (24px)
- **Body Text:** text-base leading-7 (16px, generous line-height)
- **Code Comments:** text-sm text-muted (14px)
- **Captions/Metadata:** text-xs (12px)

---

## Layout System

### Spacing Primitives
Use Tailwind units: **2, 4, 6, 8, 12, 16, 24** for consistent rhythm
- Component padding: p-4 to p-6
- Section spacing: gap-6 to gap-8
- Page margins: p-6 md:p-8 lg:p-12
- Content max-width: max-w-7xl for main container, max-w-4xl for reading content

### Grid Structure
- **Sidebar Navigation:** Fixed 280px width (lg:w-[280px]), collapsible on mobile
- **Main Content Area:** Flexible with max-width constraints
- **Right Panel (Optional):** 320px for progress tracking, table of contents

---

## Component Library

### Navigation Components

**Primary Sidebar**
- Dark surface background with subtle border
- Language sections with expand/collapse accordions
- Current chapter highlighted with primary color left border (border-l-4)
- Progress indicators next to each chapter (circular badges: 3/10)
- Smooth transitions on hover (subtle bg-surface-elevated)

**Top Header**
- Fixed position with backdrop blur (backdrop-blur-xl bg-background/80)
- Search bar prominently placed (w-full max-w-md)
- User progress summary on right (avatar + level badge)
- Breadcrumb navigation: Language > Level > Chapter

### Content Components

**Chapter View Container**
- Two-column layout for wide screens (theory left, code right)
- Single column stack on mobile/tablet
- Sticky table of contents for long chapters

**Theory Sections**
- Generous padding (p-8 md:p-12)
- Clear visual hierarchy with consistent heading spacing
- Inline code highlights: bg-accent/10 text-accent rounded px-1.5 py-0.5
- Callout boxes for tips (border-l-4 border-primary bg-primary/5 p-4)

**Monaco Editor Integration**
- Height: 400-600px depending on code complexity
- Theme: VS Dark (matches overall dark aesthetic)
- Action buttons above editor: "Run Code", "Reset", "Copy"
- Output panel below with console-style display
- Border: border border-border rounded-lg overflow-hidden

**Exercise Cards**
- Elevated surface (bg-surface-elevated)
- Clear difficulty indicator (badge: Beginner/Intermediate/Advanced)
- Estimated time to complete
- "Start Exercise" CTA button (primary colored)
- Completion checkmark when done

### Interactive Elements

**Progress Tracker**
- Circular progress ring showing overall language completion
- Linear progress bars for each difficulty level
- Achievement badges for milestones (unlocked in color, locked in grayscale)
- Weekly streak counter

**Search Interface**
- Instant results overlay (modal-style)
- Results categorized by: Languages, Chapters, Exercises
- Keyboard navigation support (↑↓ to navigate, Enter to select)
- Recent searches displayed

**Bookmark System**
- Star icon button on chapters (subtle by default, filled when bookmarked)
- Bookmarks page showing cards grid of saved chapters
- Quick access dropdown from header

### Forms & Inputs

**Quiz Components**
- Multiple choice with radio buttons (large click targets)
- Code completion exercises with inline Monaco snippets
- Immediate feedback on submission (green checkmark or red explanation)
- "Explain Answer" expandable section

**Code Execution Feedback**
- Success: Green border with checkmark icon
- Error: Red border with error message in monospace
- Loading: Subtle pulsing border animation (only when running code)

---

## Visual Treatments

### Elevation & Depth
- Cards: border border-border bg-surface shadow-sm
- Elevated Cards: border border-border bg-surface-elevated shadow-md
- Modals: border border-border bg-surface-elevated shadow-2xl

### Interactive States
- Hover: bg-surface-elevated transition-colors duration-200
- Active/Selected: bg-primary/10 border-l-4 border-primary
- Focus: ring-2 ring-primary ring-offset-2 ring-offset-background

### Icons
Use **Lucide React** exclusively (already in dependencies)
- Navigation icons: size 20px (w-5 h-5)
- Action buttons: size 18px (w-4.5 h-4.5)
- Inline icons: size 16px (w-4 h-4)
- Consistent stroke width: stroke-2

---

## Page Layouts

### Landing/Dashboard Page
- Hero section: 60vh with gradient overlay
- Feature grid: 3 columns desktop, 2 tablet, 1 mobile showing language cards
- Each language card: Icon, name, progress ring, chapters count, "Continue" CTA
- Recent activity timeline on right column

### Language Overview Page
- Header with language logo, description, total chapters count
- Three sections: Beginner | Intermediate | Advanced (visual separators)
- Chapter cards in grid with completion checkmarks
- Recommended next chapter highlighted

### Chapter Learning Page
- Sticky progress bar at top (thin, 2px height)
- Content split: Theory and explanations fill 60%, Code examples 40%
- Navigation: Previous/Next chapter buttons at bottom
- Floating "Mark Complete" button (bottom-right, fixed position)

### Profile/Progress Page
- Statistics cards showing: Total hours, Chapters completed, Streak days
- Heatmap calendar showing daily activity (GitHub-style)
- Badges and achievements showcase
- Bookmarked chapters quick access

---

## Responsive Behavior

### Breakpoints
- Mobile: < 768px - Sidebar collapsed to hamburger, single column content
- Tablet: 768px - 1024px - Sidebar toggleable, optimized two-column where appropriate
- Desktop: > 1024px - Full sidebar visible, multi-column layouts

### Mobile Optimizations
- Bottom navigation bar with: Home, Search, Progress, Profile
- Swipeable chapter navigation (swipe right for next)
- Collapsible code editors (expand to full screen on tap)
- Touch-friendly button sizes (min-height: 44px)

---

## Images

**No hero images required** - This is a utility-focused learning platform where content is king. Use:
- Language logo icons in SVG format (Python snake, JS logo, Java cup)
- Achievement badge illustrations (flat, geometric style)
- Empty state illustrations (minimal line art for "no bookmarks yet")
- User avatars (circular, generated from initials if no photo)

All images should maintain the dark theme aesthetic with limited color usage.