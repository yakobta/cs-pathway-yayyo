import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Play, RotateCcw, Copy, Check } from "lucide-react";
import { useState } from "react";

interface CodeEditorProps {
  language: string;
  initialCode: string;
  onRun?: (code: string) => void;
}

export function CodeEditor({ language, initialCode, onRun }: CodeEditorProps) {
  const [code, setCode] = useState(initialCode);
  const [output, setOutput] = useState("");
  const [isRunning, setIsRunning] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleRun = () => {
    setIsRunning(true);
    if (onRun) {
      onRun(code);
    }
    setTimeout(() => {
      setOutput("Output: Hello, World!\n> Code executed successfully");
      setIsRunning(false);
    }, 800);
  };

  const handleReset = () => {
    setCode(initialCode);
    setOutput("");
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Card className="overflow-hidden border border-border" data-testid="card-code-editor">
      <div className="bg-muted px-4 py-2 flex items-center justify-between border-b border-border">
        <span className="text-sm font-mono text-muted-foreground">{language}</span>
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={handleCopy}
            data-testid="button-copy-code"
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={handleReset}
            data-testid="button-reset-code"
          >
            <RotateCcw className="w-4 h-4" />
          </Button>
          <Button
            size="sm"
            onClick={handleRun}
            disabled={isRunning}
            data-testid="button-run-code"
          >
            <Play className="w-4 h-4 mr-1" />
            Run
          </Button>
        </div>
      </div>

      <div className="relative">
        <textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          className="w-full h-64 p-4 bg-card text-foreground font-mono text-sm resize-none focus:outline-none"
          spellCheck={false}
          data-testid="input-code-editor"
        />
      </div>

      {output && (
        <div className="bg-muted border-t border-border p-4">
          <div className="text-xs font-mono text-muted-foreground mb-1">Output:</div>
          <pre className="text-sm font-mono text-foreground whitespace-pre-wrap" data-testid="text-code-output">
            {output}
          </pre>
        </div>
      )}
    </Card>
  );
}
