import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { BookOpen, ChevronRight } from "lucide-react";

interface LanguageCardProps {
  id: string;
  name: string;
  icon: string;
  description: string;
  totalChapters: number;
  completedChapters: number;
  difficulty: "Beginner" | "Intermediate" | "Advanced";
  color: string;
  onContinue: () => void;
}

export function LanguageCard({
  name,
  icon,
  description,
  totalChapters,
  completedChapters,
  difficulty,
  color,
  onContinue,
}: LanguageCardProps) {
  const progressPercent = (completedChapters / totalChapters) * 100;

  return (
    <Card className="p-6 hover-elevate active-elevate-2 transition-all duration-200" data-testid={`card-language-${name.toLowerCase()}`}>
      <div className="flex items-start gap-4">
        <div className={`text-5xl ${color}`}>{icon}</div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 mb-2">
            <h3 className="text-xl font-semibold">{name}</h3>
            <Badge variant="outline" data-testid={`badge-difficulty-${difficulty.toLowerCase()}`}>
              {difficulty}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{description}</p>
          
          <div className="space-y-2 mb-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground flex items-center gap-1">
                <BookOpen className="w-4 h-4" />
                {completedChapters} / {totalChapters} chapters
              </span>
              <span className="text-muted-foreground">{Math.round(progressPercent)}%</span>
            </div>
            <Progress value={progressPercent} className="h-2" data-testid="progress-language" />
          </div>

          <Button 
            onClick={onContinue} 
            className="w-full" 
            data-testid={`button-continue-${name.toLowerCase()}`}
          >
            {completedChapters > 0 ? "Continue Learning" : "Start Learning"}
            <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        </div>
      </div>
    </Card>
  );
}
