import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Lock, Star } from "lucide-react";
import { cn } from "@/lib/utils";

interface ChapterListItemProps {
  id: string;
  title: string;
  description: string;
  duration: string;
  isCompleted: boolean;
  isLocked: boolean;
  isBookmarked: boolean;
  difficulty: "Beginner" | "Intermediate" | "Advanced";
  onClick: () => void;
  onToggleBookmark: () => void;
}

export function ChapterListItem({
  title,
  description,
  duration,
  isCompleted,
  isLocked,
  isBookmarked,
  difficulty,
  onClick,
  onToggleBookmark,
}: ChapterListItemProps) {
  const difficultyColors = {
    Beginner: "text-success",
    Intermediate: "text-warning",
    Advanced: "text-destructive",
  };

  return (
    <Card
      className={cn(
        "p-4 hover-elevate active-elevate-2 transition-all duration-200",
        isLocked && "opacity-60",
        isCompleted && "border-l-4 border-l-success"
      )}
      onClick={isLocked ? undefined : onClick}
      data-testid={`card-chapter-${title.toLowerCase().replace(/\s+/g, '-')}`}
    >
      <div className="flex items-start gap-4">
        <div className={cn(
          "w-10 h-10 rounded-md flex items-center justify-center flex-shrink-0",
          isCompleted ? "bg-success/20" : "bg-muted"
        )}>
          {isCompleted ? (
            <Check className="w-5 h-5 text-success" />
          ) : isLocked ? (
            <Lock className="w-5 h-5 text-muted-foreground" />
          ) : (
            <span className={cn("text-lg font-semibold", difficultyColors[difficulty])}>
              {difficulty[0]}
            </span>
          )}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 mb-1">
            <h4 className="font-semibold text-base">{title}</h4>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleBookmark();
              }}
              className="text-muted-foreground hover:text-warning transition-colors"
              data-testid="button-bookmark"
            >
              <Star className={cn("w-4 h-4", isBookmarked && "fill-warning text-warning")} />
            </button>
          </div>
          <p className="text-sm text-muted-foreground mb-2 line-clamp-1">{description}</p>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs" data-testid="badge-duration">
              {duration}
            </Badge>
            <Badge variant="outline" className="text-xs" data-testid="badge-difficulty">
              {difficulty}
            </Badge>
          </div>
        </div>
      </div>
    </Card>
  );
}
