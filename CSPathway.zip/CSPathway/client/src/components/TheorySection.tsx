import { Card } from "@/components/ui/card";
import { Info } from "lucide-react";

interface TheorySectionProps {
  title: string;
  content: string;
  tip?: string;
}

export function TheorySection({ title, content, tip }: TheorySectionProps) {
  return (
    <div className="space-y-4" data-testid="section-theory">
      <h2 className="text-2xl font-semibold">{title}</h2>
      <div className="prose prose-invert max-w-none">
        <p className="text-base leading-7 text-foreground">{content}</p>
      </div>
      {tip && (
        <Card className="p-4 border-l-4 border-l-primary bg-primary/5">
          <div className="flex gap-3">
            <Info className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium mb-1">Tip</p>
              <p className="text-sm text-muted-foreground">{tip}</p>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
