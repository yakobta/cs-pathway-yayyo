import { ProgressRing } from "../ProgressRing";

export default function ProgressRingExample() {
  return (
    <div className="p-6 bg-background flex items-center justify-center gap-8">
      <ProgressRing progress={33} />
      <ProgressRing progress={67} />
      <ProgressRing progress={100} />
    </div>
  );
}
