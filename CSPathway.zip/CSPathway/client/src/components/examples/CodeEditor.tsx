import { CodeEditor } from "../CodeEditor";

export default function CodeEditorExample() {
  return (
    <div className="p-6 bg-background">
      <CodeEditor
        language="python"
        initialCode={`print("Hello, World!")

# Try modifying this code
name = "Student"
print(f"Welcome, {name}!")`}
        onRun={(code) => console.log("Running code:", code)}
      />
    </div>
  );
}
