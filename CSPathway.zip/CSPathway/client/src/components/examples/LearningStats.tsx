import { LearningStats } from "../LearningStats";

export default function LearningStatsExample() {
  return (
    <div className="p-6 bg-background">
      <LearningStats
        totalHours={42}
        chaptersCompleted={28}
        currentStreak={7}
        badgesEarned={12}
      />
    </div>
  );
}
