import { LanguageCard } from "../LanguageCard";

export default function LanguageCardExample() {
  return (
    <div className="p-6 bg-background">
      <LanguageCard
        id="python"
        name="Python"
        icon="🐍"
        description="A versatile, beginner-friendly language perfect for web development, data science, and automation."
        totalChapters={24}
        completedChapters={8}
        difficulty="Beginner"
        color="text-blue-400"
        onContinue={() => console.log("Continue Python clicked")}
      />
    </div>
  );
}
