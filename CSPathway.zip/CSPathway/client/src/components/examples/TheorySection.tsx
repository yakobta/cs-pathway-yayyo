import { TheorySection } from "../TheorySection";

export default function TheorySectionExample() {
  return (
    <div className="p-6 bg-background">
      <TheorySection
        title="Variables in Python"
        content="Variables are containers for storing data values. In Python, you don't need to declare the type of a variable. Python automatically determines the data type based on the value assigned to it. This feature is called dynamic typing."
        tip="Use descriptive variable names to make your code more readable. For example, use 'student_name' instead of just 'n'."
      />
    </div>
  );
}
