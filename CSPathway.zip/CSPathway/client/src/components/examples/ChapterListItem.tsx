import { ChapterListItem } from "../ChapterListItem";
import { useState } from "react";

export default function ChapterListItemExample() {
  const [isBookmarked, setIsBookmarked] = useState(false);

  return (
    <div className="p-6 bg-background space-y-4">
      <ChapterListItem
        id="1"
        title="Python Basics & Syntax"
        description="Learn the fundamental syntax and structure of Python programming"
        duration="45 min"
        isCompleted={true}
        isLocked={false}
        isBookmarked={isBookmarked}
        difficulty="Beginner"
        onClick={() => console.log("Chapter clicked")}
        onToggleBookmark={() => setIsBookmarked(!isBookmarked)}
      />
      <ChapterListItem
        id="2"
        title="Data Types & Variables"
        description="Understanding Python's built-in data types and variable declarations"
        duration="60 min"
        isCompleted={false}
        isLocked={false}
        isBookmarked={false}
        difficulty="Beginner"
        onClick={() => console.log("Chapter clicked")}
        onToggleBookmark={() => console.log("Bookmark toggled")}
      />
      <ChapterListItem
        id="3"
        title="Advanced OOP Concepts"
        description="Master object-oriented programming with inheritance and polymorphism"
        duration="90 min"
        isCompleted={false}
        isLocked={true}
        isBookmarked={false}
        difficulty="Advanced"
        onClick={() => console.log("Chapter clicked")}
        onToggleBookmark={() => console.log("Bookmark toggled")}
      />
    </div>
  );
}
