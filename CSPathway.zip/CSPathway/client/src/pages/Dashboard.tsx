import { LanguageCard } from "@/components/LanguageCard";
import { LearningStats } from "@/components/LearningStats";
import { SearchBar } from "@/components/SearchBar";
import { useState } from "react";

const languages = [
  {
    id: "python",
    name: "Python",
    icon: "🐍",
    description: "A versatile, beginner-friendly language perfect for web development, data science, and automation.",
    totalChapters: 24,
    completedChapters: 8,
    difficulty: "Beginner" as const,
    color: "text-blue-400",
  },
  {
    id: "javascript",
    name: "JavaScript",
    icon: "⚡",
    description: "The language of the web. Build interactive websites and modern web applications.",
    totalChapters: 28,
    completedChapters: 0,
    difficulty: "Beginner" as const,
    color: "text-yellow-400",
  },
  {
    id: "java",
    name: "Java",
    icon: "☕",
    description: "Enterprise-grade programming language used for Android development and large-scale applications.",
    totalChapters: 32,
    completedChapters: 0,
    difficulty: "Intermediate" as const,
    color: "text-orange-400",
  },
  {
    id: "cpp",
    name: "C++",
    icon: "⚙️",
    description: "High-performance language for system programming, game development, and competitive coding.",
    totalChapters: 30,
    completedChapters: 0,
    difficulty: "Advanced" as const,
    color: "text-purple-400",
  },
  {
    id: "html-css",
    name: "HTML/CSS",
    icon: "🎨",
    description: "Build beautiful, responsive websites with the foundational technologies of the web.",
    totalChapters: 20,
    completedChapters: 0,
    difficulty: "Beginner" as const,
    color: "text-pink-400",
  },
  {
    id: "sql",
    name: "SQL",
    icon: "🗄️",
    description: "Master database management and data manipulation with Structured Query Language.",
    totalChapters: 18,
    completedChapters: 0,
    difficulty: "Beginner" as const,
    color: "text-cyan-400",
  },
];

export default function Dashboard() {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredLanguages = languages.filter(lang =>
    lang.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    lang.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="p-6 md:p-8 space-y-8">
      <div>
        <h1 className="text-4xl font-bold mb-2">Welcome back!</h1>
        <p className="text-muted-foreground">Continue your learning journey</p>
      </div>

      <LearningStats
        totalHours={42}
        chaptersCompleted={8}
        currentStreak={7}
        badgesEarned={3}
      />

      <div>
        <SearchBar onSearch={setSearchQuery} />
      </div>

      <div>
        <h2 className="text-2xl font-semibold mb-4">Your Languages</h2>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {filteredLanguages.map((lang) => (
            <LanguageCard
              key={lang.id}
              {...lang}
              onContinue={() => console.log(`Continue ${lang.name}`)}
            />
          ))}
        </div>
        {filteredLanguages.length === 0 && (
          <p className="text-center text-muted-foreground py-8">No languages found</p>
        )}
      </div>
    </div>
  );
}
