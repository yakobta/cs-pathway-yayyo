import { TheorySection } from "@/components/TheorySection";
import { CodeEditor } from "@/components/CodeEditor";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ChevronLeft, ChevronRight, Check } from "lucide-react";
import { useState } from "react";

export default function ChapterView() {
  const [isCompleted, setIsCompleted] = useState(false);

  return (
    <div className="p-6 md:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>Python</span>
            <span>/</span>
            <span>Beginner</span>
            <span>/</span>
            <span className="text-foreground">Variables & Data Types</span>
          </div>
          <Progress value={33} className="w-32 h-2" data-testid="progress-chapter" />
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <TheorySection
              title="Variables & Data Types"
              content="Variables are containers for storing data values. In Python, you don't need to declare the type of a variable. Python automatically determines the data type based on the value assigned to it. This feature is called dynamic typing. Common data types include strings (text), integers (whole numbers), floats (decimal numbers), and booleans (True/False)."
              tip="Use descriptive variable names to make your code more readable. For example, use 'student_name' instead of just 'n'."
            />

            <div className="space-y-3">
              <h3 className="text-lg font-semibold">Key Concepts:</h3>
              <ul className="space-y-2 text-foreground">
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span>Variables store data that can be used and modified</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span>Python uses dynamic typing (no type declaration needed)</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span>Common types: str, int, float, bool</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold mb-3">Try it yourself:</h3>
              <CodeEditor
                language="python"
                initialCode={`# Variables in Python
name = "Alice"
age = 25
height = 5.6
is_student = True

print(f"Name: {name}")
print(f"Age: {age}")
print(f"Height: {height}")
print(f"Student: {is_student}")`}
                onRun={(code) => console.log("Running:", code)}
              />
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between pt-6 border-t border-border">
          <Button variant="outline" data-testid="button-previous-chapter">
            <ChevronLeft className="w-4 h-4 mr-1" />
            Previous
          </Button>
          <Button
            variant={isCompleted ? "outline" : "default"}
            onClick={() => setIsCompleted(!isCompleted)}
            data-testid="button-mark-complete"
          >
            {isCompleted ? (
              <>
                <Check className="w-4 h-4 mr-1" />
                Completed
              </>
            ) : (
              "Mark as Complete"
            )}
          </Button>
          <Button data-testid="button-next-chapter">
            Next
            <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        </div>
      </div>
    </div>
  );
}
