import { ChapterListItem } from "@/components/ChapterListItem";
import { ProgressRing } from "@/components/ProgressRing";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";

const chapters = {
  beginner: [
    {
      id: "1",
      title: "Python Basics & Syntax",
      description: "Learn the fundamental syntax and structure of Python programming",
      duration: "45 min",
      isCompleted: true,
      isLocked: false,
    },
    {
      id: "2",
      title: "Variables & Data Types",
      description: "Understanding Python's built-in data types and variable declarations",
      duration: "60 min",
      isCompleted: true,
      isLocked: false,
    },
    {
      id: "3",
      title: "Control Flow & Conditionals",
      description: "Master if-else statements and logical operators",
      duration: "55 min",
      isCompleted: false,
      isLocked: false,
    },
    {
      id: "4",
      title: "Loops & Iterations",
      description: "Learn for loops, while loops, and iteration techniques",
      duration: "70 min",
      isCompleted: false,
      isLocked: false,
    },
  ],
  intermediate: [
    {
      id: "5",
      title: "Functions & Modules",
      description: "Create reusable code with functions and organize with modules",
      duration: "80 min",
      isCompleted: false,
      isLocked: false,
    },
    {
      id: "6",
      title: "Data Structures",
      description: "Master lists, tuples, dictionaries, and sets",
      duration: "90 min",
      isCompleted: false,
      isLocked: false,
    },
  ],
  advanced: [
    {
      id: "7",
      title: "Object-Oriented Programming",
      description: "Learn classes, objects, inheritance, and polymorphism",
      duration: "120 min",
      isCompleted: false,
      isLocked: true,
    },
  ],
};

export default function LanguageOverview() {
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);

  const toggleBookmark = (id: string) => {
    setBookmarkedIds(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const totalChapters = Object.values(chapters).flat().length;
  const completedChapters = Object.values(chapters).flat().filter(c => c.isCompleted).length;
  const progress = (completedChapters / totalChapters) * 100;

  return (
    <div className="p-6 md:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <span className="text-5xl">🐍</span>
              <div>
                <h1 className="text-4xl font-bold">Python</h1>
                <p className="text-muted-foreground">From basics to advanced concepts</p>
              </div>
            </div>
          </div>
          <ProgressRing progress={progress} />
        </div>

        <Tabs defaultValue="beginner" className="space-y-6">
          <TabsList data-testid="tabs-difficulty-levels">
            <TabsTrigger value="beginner" data-testid="tab-beginner">
              Beginner
              <Badge variant="outline" className="ml-2">{chapters.beginner.length}</Badge>
            </TabsTrigger>
            <TabsTrigger value="intermediate" data-testid="tab-intermediate">
              Intermediate
              <Badge variant="outline" className="ml-2">{chapters.intermediate.length}</Badge>
            </TabsTrigger>
            <TabsTrigger value="advanced" data-testid="tab-advanced">
              Advanced
              <Badge variant="outline" className="ml-2">{chapters.advanced.length}</Badge>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="beginner" className="space-y-3">
            {chapters.beginner.map((chapter) => (
              <ChapterListItem
                key={chapter.id}
                {...chapter}
                difficulty="Beginner"
                isBookmarked={bookmarkedIds.includes(chapter.id)}
                onClick={() => console.log("Open chapter:", chapter.id)}
                onToggleBookmark={() => toggleBookmark(chapter.id)}
              />
            ))}
          </TabsContent>

          <TabsContent value="intermediate" className="space-y-3">
            {chapters.intermediate.map((chapter) => (
              <ChapterListItem
                key={chapter.id}
                {...chapter}
                difficulty="Intermediate"
                isBookmarked={bookmarkedIds.includes(chapter.id)}
                onClick={() => console.log("Open chapter:", chapter.id)}
                onToggleBookmark={() => toggleBookmark(chapter.id)}
              />
            ))}
          </TabsContent>

          <TabsContent value="advanced" className="space-y-3">
            {chapters.advanced.map((chapter) => (
              <ChapterListItem
                key={chapter.id}
                {...chapter}
                difficulty="Advanced"
                isBookmarked={bookmarkedIds.includes(chapter.id)}
                onClick={() => console.log("Open chapter:", chapter.id)}
                onToggleBookmark={() => toggleBookmark(chapter.id)}
              />
            ))}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
